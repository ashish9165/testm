import express from 'express';
import { body, validationResult } from 'express-validator';
import Doctor from '../models/Doctor.js';
import Patient from '../models/Patient.js';
import Appointment from '../models/Appointment.js';
import { auth, authorize } from '../middleware/auth.js';

const router = express.Router();

// @route   POST /api/doctor/login
// @desc    Doctor login
// @access  Public
router.post('/login', [
  body('email').isEmail().withMessage('Please provide a valid email'),
  body('password').notEmpty().withMessage('Password is required')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Validation failed',
        errors: errors.array()
      });
    }

    const { email, password } = req.body;

    // Find doctor and include password for comparison
    const doctor = await Doctor.findOne({ email }).select('+password');

    if (!doctor) {
      return res.status(401).json({
        success: false,
        message: 'Invalid credentials'
      });
    }

    if (!doctor.isActive) {
      return res.status(401).json({
        success: false,
        message: 'Account is deactivated'
      });
    }

    // Check password
    const isPasswordMatch = await doctor.comparePassword(password);

    if (!isPasswordMatch) {
      return res.status(401).json({
        success: false,
        message: 'Invalid credentials'
      });
    }

    // Update last login
    doctor.lastLogin = new Date();
    await doctor.save();

    // Generate token
    const { generateToken } = await import('../middleware/auth.js');
    const token = generateToken(doctor._id, 'doctor');

    res.status(200).json({
      success: true,
      message: 'Doctor logged in successfully',
      token,
      doctor: {
        id: doctor._id,
        name: doctor.name,
        email: doctor.email,
        specialization: doctor.specialization,
        phone: doctor.phone,
        experience: doctor.experience,
        consultationFee: doctor.consultationFee
      }
    });

  } catch (error) {
    console.error('Doctor login error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error during login'
    });
  }
});

// @route   GET /api/doctor/dashboard
// @desc    Get doctor dashboard data
// @access  Private (Doctor)
router.get('/dashboard', auth, authorize('doctor'), async (req, res) => {
  try {
    const doctor = await Doctor.findById(req.user._id)
      .populate('patientsAssigned', 'name age email phone symptoms')
      .populate('department', 'name location');

    if (!doctor) {
      return res.status(404).json({
        success: false,
        message: 'Doctor not found'
      });
    }

    // Get today's appointments
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    const todaysAppointments = await Appointment.find({
      doctorId: doctor._id,
      date: { $gte: today, $lt: tomorrow },
      status: { $in: ['pending', 'approved'] }
    }).populate('patientId', 'name age phone symptoms');

    // Get pending appointments
    const pendingAppointments = await Appointment.find({
      doctorId: doctor._id,
      status: 'pending'
    }).populate('patientId', 'name age phone symptoms')
      .sort({ createdAt: -1 })
      .limit(10);

    // Get recent completed appointments
    const recentAppointments = await Appointment.find({
      doctorId: doctor._id,
      status: 'completed'
    }).populate('patientId', 'name age phone')
      .sort({ date: -1 })
      .limit(5);

    res.status(200).json({
      success: true,
      data: {
        doctor: {
          id: doctor._id,
          name: doctor.name,
          specialization: doctor.specialization,
          department: doctor.department,
          experience: doctor.experience,
          consultationFee: doctor.consultationFee,
          patientsAssigned: doctor.patientsAssigned,
          isAvailable: doctor.isAvailable
        },
        todaysAppointments,
        pendingAppointments,
        recentAppointments,
        stats: {
          totalPatients: doctor.patientsAssigned.length,
          todaysAppointments: todaysAppointments.length,
          pendingAppointments: pendingAppointments.length
        }
      }
    });

  } catch (error) {
    console.error('Doctor dashboard error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching dashboard data'
    });
  }
});

// @route   GET /api/doctor/patients
// @desc    Get assigned patients
// @access  Private (Doctor)
router.get('/patients', auth, authorize('doctor'), async (req, res) => {
  try {
    const doctor = await Doctor.findById(req.user._id)
      .populate({
        path: 'patientsAssigned',
        populate: {
          path: 'appointments',
          match: { doctorId: req.user._id },
          options: { sort: { date: -1 } }
        }
      });

    if (!doctor) {
      return res.status(404).json({
        success: false,
        message: 'Doctor not found'
      });
    }

    res.status(200).json({
      success: true,
      data: {
        patients: doctor.patientsAssigned
      }
    });

  } catch (error) {
    console.error('Get patients error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching patients'
    });
  }
});

// @route   GET /api/doctor/patient/:patientId
// @desc    Get specific patient details
// @access  Private (Doctor)
router.get('/patient/:patientId', auth, authorize('doctor'), async (req, res) => {
  try {
    const { patientId } = req.params;

    // Check if patient is assigned to this doctor
    const doctor = await Doctor.findById(req.user._id);
    if (!doctor.patientsAssigned.includes(patientId)) {
      return res.status(403).json({
        success: false,
        message: 'Patient not assigned to you'
      });
    }

    const patient = await Patient.findById(patientId)
      .populate('assignedDoctor', 'name specialization')
      .populate({
        path: 'appointments',
        match: { doctorId: req.user._id },
        options: { sort: { date: -1 } }
      });

    if (!patient) {
      return res.status(404).json({
        success: false,
        message: 'Patient not found'
      });
    }

    res.status(200).json({
      success: true,
      data: {
        patient: {
          id: patient._id,
          name: patient.name,
          age: patient.age,
          email: patient.email,
          phone: patient.phone,
          symptoms: patient.symptoms,
          medicalHistory: patient.medicalHistory,
          appointments: patient.appointments,
          emergencyContact: patient.emergencyContact,
          address: patient.address,
          bloodType: patient.bloodType,
          allergies: patient.allergies,
          currentMedications: patient.currentMedications
        }
      }
    });

  } catch (error) {
    console.error('Get patient error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching patient details'
    });
  }
});

// @route   PUT /api/doctor/appointment/:appointmentId/status
// @desc    Update appointment status
// @access  Private (Doctor)
router.put('/appointment/:appointmentId/status', [
  auth,
  authorize('doctor'),
  body('status').isIn(['approved', 'rejected', 'completed', 'cancelled']).withMessage('Invalid status')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Validation failed',
        errors: errors.array()
      });
    }

    const { appointmentId } = req.params;
    const { status } = req.body;

    const appointment = await Appointment.findOne({
      _id: appointmentId,
      doctorId: req.user._id
    });

    if (!appointment) {
      return res.status(404).json({
        success: false,
        message: 'Appointment not found or not assigned to you'
      });
    }

    appointment.status = status;
    await appointment.save();

    res.status(200).json({
      success: true,
      message: 'Appointment status updated successfully',
      data: { appointment }
    });

  } catch (error) {
    console.error('Update appointment status error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while updating appointment status'
    });
  }
});

// @route   POST /api/doctor/patient/:patientId/medical-record
// @desc    Add medical record for patient
// @access  Private (Doctor)
router.post('/patient/:patientId/medical-record', [
  auth,
  authorize('doctor'),
  body('diagnosis').notEmpty().withMessage('Diagnosis is required'),
  body('prescription').optional().isArray(),
  body('treatmentNotes').optional().isString()
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Validation failed',
        errors: errors.array()
      });
    }

    const { patientId } = req.params;
    const { diagnosis, prescription, treatmentNotes } = req.body;

    // Check if patient is assigned to this doctor
    const doctor = await Doctor.findById(req.user._id);
    if (!doctor.patientsAssigned.includes(patientId)) {
      return res.status(403).json({
        success: false,
        message: 'Patient not assigned to you'
      });
    }

    const patient = await Patient.findById(patientId);
    if (!patient) {
      return res.status(404).json({
        success: false,
        message: 'Patient not found'
      });
    }

    // Add medical record
    const medicalRecord = {
      diagnosis,
      prescription,
      treatmentNotes,
      doctor: req.user._id
    };

    patient.medicalHistory.push(medicalRecord);
    await patient.save();

    res.status(201).json({
      success: true,
      message: 'Medical record added successfully',
      data: { medicalRecord }
    });

  } catch (error) {
    console.error('Add medical record error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while adding medical record'
    });
  }
});

// @route   PUT /api/doctor/availability
// @desc    Update doctor availability
// @access  Private (Doctor)
router.put('/availability', [
  auth,
  authorize('doctor'),
  body('isAvailable').isBoolean().withMessage('isAvailable must be a boolean'),
  body('availability').optional().isObject()
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Validation failed',
        errors: errors.array()
      });
    }

    const { isAvailable, availability } = req.body;

    const doctor = await Doctor.findById(req.user._id);
    if (!doctor) {
      return res.status(404).json({
        success: false,
        message: 'Doctor not found'
      });
    }

    doctor.isAvailable = isAvailable;
    if (availability) {
      doctor.availability = { ...doctor.availability, ...availability };
    }

    await doctor.save();

    res.status(200).json({
      success: true,
      message: 'Availability updated successfully',
      data: { doctor }
    });

  } catch (error) {
    console.error('Update availability error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while updating availability'
    });
  }
});

// @route   GET /api/doctor/appointments
// @desc    Get doctor's appointments
// @access  Private (Doctor)
router.get('/appointments', auth, authorize('doctor'), async (req, res) => {
  try {
    const { status, date, page = 1, limit = 10 } = req.query;
    const query = { doctorId: req.user._id };

    if (status) {
      query.status = status;
    }

    if (date) {
      const startDate = new Date(date);
      const endDate = new Date(date);
      endDate.setDate(endDate.getDate() + 1);
      query.date = { $gte: startDate, $lt: endDate };
    }

    const appointments = await Appointment.find(query)
      .populate('patientId', 'name age phone symptoms')
      .sort({ date: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const total = await Appointment.countDocuments(query);

    res.status(200).json({
      success: true,
      data: {
        appointments,
        pagination: {
          current: parseInt(page),
          pages: Math.ceil(total / limit),
          total
        }
      }
    });

  } catch (error) {
    console.error('Get appointments error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching appointments'
    });
  }
});

export default router;
