import express from 'express';
import { body, validationResult } from 'express-validator';
import Admin from '../models/Admin.js';
import Doctor from '../models/Doctor.js';
import Patient from '../models/Patient.js';
import Appointment from '../models/Appointment.js';
import Department from '../models/Department.js';
import { auth, authorize } from '../middleware/auth.js';

const router = express.Router();

// @route   POST /api/admin/login
// @desc    Admin login
// @access  Public
router.post('/login', [
  body('email').isEmail().withMessage('Please provide a valid email'),
  body('password').notEmpty().withMessage('Password is required')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Validation failed',
        errors: errors.array()
      });
    }

    const { email, password } = req.body;

    // Find admin and include password for comparison
    const admin = await Admin.findOne({ email }).select('+password');

    if (!admin) {
      return res.status(401).json({
        success: false,
        message: 'Invalid credentials'
      });
    }

    if (!admin.isActive) {
      return res.status(401).json({
        success: false,
        message: 'Account is deactivated'
      });
    }

    // Check password
    const isPasswordMatch = await admin.comparePassword(password);

    if (!isPasswordMatch) {
      return res.status(401).json({
        success: false,
        message: 'Invalid credentials'
      });
    }

    // Update last login
    admin.lastLogin = new Date();
    await admin.save();

    // Generate token
    const { generateToken } = await import('../middleware/auth.js');
    const token = generateToken(admin._id, 'admin');

    res.status(200).json({
      success: true,
      message: 'Admin logged in successfully',
      token,
      admin: {
        id: admin._id,
        name: admin.name,
        email: admin.email,
        role: admin.role,
        permissions: admin.permissions
      }
    });

  } catch (error) {
    console.error('Admin login error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error during login'
    });
  }
});

// @route   GET /api/admin/dashboard
// @desc    Get admin dashboard data
// @access  Private (Admin)
router.get('/dashboard', auth, authorize('admin'), async (req, res) => {
  try {
    // Get basic counts
    const totalPatients = await Patient.countDocuments({ isActive: true });
    const totalDoctors = await Doctor.countDocuments({ isActive: true });
    const totalAppointments = await Appointment.countDocuments();
    const totalDepartments = await Department.countDocuments({ isActive: true });

    // Get today's appointments
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    const todaysAppointments = await Appointment.countDocuments({
      date: { $gte: today, $lt: tomorrow }
    });

    // Get pending appointments
    const pendingAppointments = await Appointment.countDocuments({
      status: 'pending'
    });

    // Get most common symptoms
    const symptomStats = await Patient.aggregate([
      { $unwind: '$symptoms' },
      { $group: { _id: '$symptoms', count: { $sum: 1 } } },
      { $sort: { count: -1 } },
      { $limit: 10 }
    ]);

    // Get patient distribution by department
    const departmentStats = await Doctor.aggregate([
      { $lookup: { from: 'departments', localField: 'department', foreignField: '_id', as: 'dept' } },
      { $unwind: '$dept' },
      { $group: { _id: '$dept.name', patientCount: { $sum: { $size: '$patientsAssigned' } } } },
      { $sort: { patientCount: -1 } }
    ]);

    // Get appointment status distribution
    const appointmentStats = await Appointment.aggregate([
      { $group: { _id: '$status', count: { $sum: 1 } } },
      { $sort: { count: -1 } }
    ]);

    // Get recent activities
    const recentAppointments = await Appointment.find()
      .populate('patientId', 'name')
      .populate('doctorId', 'name specialization')
      .sort({ createdAt: -1 })
      .limit(10);

    res.status(200).json({
      success: true,
      data: {
        overview: {
          totalPatients,
          totalDoctors,
          totalAppointments,
          totalDepartments,
          todaysAppointments,
          pendingAppointments
        },
        charts: {
          commonSymptoms: symptomStats,
          departmentDistribution: departmentStats,
          appointmentStatus: appointmentStats
        },
        recentActivities: recentAppointments
      }
    });

  } catch (error) {
    console.error('Admin dashboard error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching dashboard data'
    });
  }
});

// @route   GET /api/admin/doctors
// @desc    Get all doctors
// @access  Private (Admin)
router.get('/doctors', auth, authorize('admin'), async (req, res) => {
  try {
    const { page = 1, limit = 10, specialization, isActive } = req.query;
    const query = {};

    if (specialization) {
      query.specialization = specialization;
    }

    if (isActive !== undefined) {
      query.isActive = isActive === 'true';
    }

    const doctors = await Doctor.find(query)
      .populate('department', 'name')
      .select('-password')
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const total = await Doctor.countDocuments(query);

    res.status(200).json({
      success: true,
      data: {
        doctors,
        pagination: {
          current: parseInt(page),
          pages: Math.ceil(total / limit),
          total
        }
      }
    });

  } catch (error) {
    console.error('Get doctors error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching doctors'
    });
  }
});

// @route   POST /api/admin/doctors
// @desc    Create new doctor
// @access  Private (Admin)
router.post('/doctors', [
  auth,
  authorize('admin'),
  body('name').notEmpty().withMessage('Name is required'),
  body('email').isEmail().withMessage('Please provide a valid email'),
  body('password').isLength({ min: 6 }).withMessage('Password must be at least 6 characters'),
  body('specialization').notEmpty().withMessage('Specialization is required'),
  body('phone').matches(/^[\+]?[1-9][\d]{0,15}$/).withMessage('Please provide a valid phone number'),
  body('licenseNumber').notEmpty().withMessage('License number is required'),
  body('department').isMongoId().withMessage('Please provide a valid department ID'),
  body('experience').isInt({ min: 0 }).withMessage('Experience must be a positive number'),
  body('consultationFee').isFloat({ min: 0 }).withMessage('Consultation fee must be a positive number')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Validation failed',
        errors: errors.array()
      });
    }

    const doctor = new Doctor(req.body);
    await doctor.save();

    const populatedDoctor = await Doctor.findById(doctor._id)
      .populate('department', 'name')
      .select('-password');

    res.status(201).json({
      success: true,
      message: 'Doctor created successfully',
      data: { doctor: populatedDoctor }
    });

  } catch (error) {
    console.error('Create doctor error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while creating doctor'
    });
  }
});

// @route   PUT /api/admin/doctors/:id
// @desc    Update doctor
// @access  Private (Admin)
router.put('/doctors/:id', [
  auth,
  authorize('admin'),
  body('name').optional().isLength({ min: 2, max: 50 }),
  body('email').optional().isEmail(),
  body('specialization').optional().notEmpty(),
  body('phone').optional().matches(/^[\+]?[1-9][\d]{0,15}$/),
  body('experience').optional().isInt({ min: 0 }),
  body('consultationFee').optional().isFloat({ min: 0 })
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Validation failed',
        errors: errors.array()
      });
    }

    const { id } = req.params;
    const allowedUpdates = ['name', 'email', 'specialization', 'phone', 'licenseNumber', 'department', 'experience', 'consultationFee', 'bio', 'isActive', 'isAvailable'];

    const updates = {};
    allowedUpdates.forEach(field => {
      if (req.body[field] !== undefined) {
        updates[field] = req.body[field];
      }
    });

    const doctor = await Doctor.findByIdAndUpdate(
      id,
      updates,
      { new: true, runValidators: true }
    ).populate('department', 'name').select('-password');

    if (!doctor) {
      return res.status(404).json({
        success: false,
        message: 'Doctor not found'
      });
    }

    res.status(200).json({
      success: true,
      message: 'Doctor updated successfully',
      data: { doctor }
    });

  } catch (error) {
    console.error('Update doctor error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while updating doctor'
    });
  }
});

// @route   DELETE /api/admin/doctors/:id
// @desc    Delete doctor
// @access  Private (Admin)
router.delete('/doctors/:id', auth, authorize('admin'), async (req, res) => {
  try {
    const { id } = req.params;

    const doctor = await Doctor.findById(id);
    if (!doctor) {
      return res.status(404).json({
        success: false,
        message: 'Doctor not found'
      });
    }

    // Check if doctor has assigned patients
    if (doctor.patientsAssigned.length > 0) {
      return res.status(400).json({
        success: false,
        message: 'Cannot delete doctor with assigned patients. Please reassign patients first.'
      });
    }

    await Doctor.findByIdAndDelete(id);

    res.status(200).json({
      success: true,
      message: 'Doctor deleted successfully'
    });

  } catch (error) {
    console.error('Delete doctor error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while deleting doctor'
    });
  }
});

// @route   GET /api/admin/patients
// @desc    Get all patients
// @access  Private (Admin)
router.get('/patients', auth, authorize('admin'), async (req, res) => {
  try {
    const { page = 1, limit = 10, symptoms, assignedDoctor } = req.query;
    const query = { isActive: true };

    if (symptoms) {
      query.symptoms = { $in: [new RegExp(symptoms, 'i')] };
    }

    if (assignedDoctor) {
      query.assignedDoctor = assignedDoctor;
    }

    const patients = await Patient.find(query)
      .populate('assignedDoctor', 'name specialization')
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const total = await Patient.countDocuments(query);

    res.status(200).json({
      success: true,
      data: {
        patients,
        pagination: {
          current: parseInt(page),
          pages: Math.ceil(total / limit),
          total
        }
      }
    });

  } catch (error) {
    console.error('Get patients error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching patients'
    });
  }
});

// @route   GET /api/admin/departments
// @desc    Get all departments
// @access  Private (Admin)
router.get('/departments', auth, authorize('admin'), async (req, res) => {
  try {
    const departments = await Department.find({ isActive: true })
      .populate('headOfDepartment', 'name specialization')
      .populate('doctors', 'name specialization')
      .sort({ name: 1 });

    res.status(200).json({
      success: true,
      data: { departments }
    });

  } catch (error) {
    console.error('Get departments error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching departments'
    });
  }
});

// @route   POST /api/admin/departments
// @desc    Create new department
// @access  Private (Admin)
router.post('/departments', [
  auth,
  authorize('admin'),
  body('name').notEmpty().withMessage('Department name is required'),
  body('description').notEmpty().withMessage('Description is required'),
  body('location.floor').isInt({ min: 1 }).withMessage('Floor must be a positive number'),
  body('location.room').notEmpty().withMessage('Room number is required'),
  body('location.building').notEmpty().withMessage('Building name is required'),
  body('contactInfo.phone').matches(/^[\+]?[1-9][\d]{0,15}$/).withMessage('Please provide a valid phone number'),
  body('contactInfo.email').isEmail().withMessage('Please provide a valid email'),
  body('capacity').isInt({ min: 1 }).withMessage('Capacity must be at least 1')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Validation failed',
        errors: errors.array()
      });
    }

    const department = new Department(req.body);
    await department.save();

    res.status(201).json({
      success: true,
      message: 'Department created successfully',
      data: { department }
    });

  } catch (error) {
    console.error('Create department error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while creating department'
    });
  }
});

// @route   GET /api/admin/reports
// @desc    Generate reports
// @access  Private (Admin)
router.get('/reports', auth, authorize('admin'), async (req, res) => {
  try {
    const { type, startDate, endDate } = req.query;

    let start, end;
    if (startDate && endDate) {
      start = new Date(startDate);
      end = new Date(endDate);
    } else {
      // Default to last 30 days
      end = new Date();
      start = new Date();
      start.setDate(start.getDate() - 30);
    }

    let reportData = {};

    switch (type) {
      case 'appointments':
        reportData = await Appointment.aggregate([
          {
            $match: {
              date: { $gte: start, $lte: end }
            }
          },
          {
            $group: {
              _id: {
                date: { $dateToString: { format: '%Y-%m-%d', date: '$date' } },
                status: '$status'
              },
              count: { $sum: 1 }
            }
          },
          { $sort: { '_id.date': 1 } }
        ]);
        break;

      case 'patients':
        reportData = await Patient.aggregate([
          {
            $match: {
              createdAt: { $gte: start, $lte: end }
            }
          },
          {
            $group: {
              _id: {
                date: { $dateToString: { format: '%Y-%m-%d', date: '$createdAt' } }
              },
              count: { $sum: 1 }
            }
          },
          { $sort: { '_id.date': 1 } }
        ]);
        break;

      case 'symptoms':
        reportData = await Patient.aggregate([
          { $unwind: '$symptoms' },
          { $group: { _id: '$symptoms', count: { $sum: 1 } } },
          { $sort: { count: -1 } },
          { $limit: 20 }
        ]);
        break;

      default:
        return res.status(400).json({
          success: false,
          message: 'Invalid report type. Available types: appointments, patients, symptoms'
        });
    }

    res.status(200).json({
      success: true,
      data: {
        type,
        startDate: start,
        endDate: end,
        reportData
      }
    });

  } catch (error) {
    console.error('Generate report error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while generating report'
    });
  }
});

export default router;
