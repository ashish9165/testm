import mongoose from 'mongoose';

const appointmentSchema = new mongoose.Schema({
  patientId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Patient',
    required: [true, 'Patient ID is required']
  },
  doctorId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Doctor',
    required: [true, 'Doctor ID is required']
  },
  date: {
    type: Date,
    required: [true, 'Appointment date is required']
  },
  time: {
    type: String,
    required: [true, 'Appointment time is required'],
    match: [/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/, 'Please provide a valid time format (HH:MM)']
  },
  status: {
    type: String,
    enum: ['pending', 'approved', 'rejected', 'completed', 'cancelled'],
    default: 'pending'
  },
  type: {
    type: String,
    enum: ['consultation', 'follow_up', 'emergency', 'routine_checkup'],
    default: 'consultation'
  },
  reason: {
    type: String,
    required: [true, 'Please provide reason for appointment'],
    maxlength: [200, 'Reason cannot be more than 200 characters']
  },
  symptoms: [String],
  notes: {
    type: String,
    maxlength: [500, 'Notes cannot be more than 500 characters']
  },
  diagnosis: {
    type: String,
    maxlength: [500, 'Diagnosis cannot be more than 500 characters']
  },
  prescription: [{
    medicine: String,
    dosage: String,
    frequency: String,
    duration: String,
    instructions: String
  }],
  followUpDate: {
    type: Date
  },
  followUpNotes: {
    type: String,
    maxlength: [500, 'Follow-up notes cannot be more than 500 characters']
  },
  consultationFee: {
    type: Number,
    min: [0, 'Consultation fee cannot be negative']
  },
  paymentStatus: {
    type: String,
    enum: ['pending', 'paid', 'refunded'],
    default: 'pending'
  },
  createdBy: {
    type: String,
    enum: ['patient', 'doctor', 'admin'],
    required: true
  }
}, {
  timestamps: true
});

// Index for better query performance
appointmentSchema.index({ patientId: 1 });
appointmentSchema.index({ doctorId: 1 });
appointmentSchema.index({ date: 1 });
appointmentSchema.index({ status: 1 });
appointmentSchema.index({ date: 1, time: 1, doctorId: 1 }, { unique: true });

// Prevent double booking
appointmentSchema.pre('save', async function(next) {
  if (this.isNew) {
    const existingAppointment = await this.constructor.findOne({
      doctorId: this.doctorId,
      date: this.date,
      time: this.time,
      status: { $in: ['pending', 'approved'] }
    });
    
    if (existingAppointment) {
      const error = new Error('Doctor is already booked at this time');
      error.statusCode = 400;
      return next(error);
    }
  }
  next();
});

export default mongoose.model('Appointment', appointmentSchema);
