import mongoose from 'mongoose';

const departmentSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Please provide department name'],
    unique: true,
    trim: true,
    maxlength: [50, 'Department name cannot be more than 50 characters']
  },
  description: {
    type: String,
    required: [true, 'Please provide department description'],
    maxlength: [500, 'Description cannot be more than 500 characters']
  },
  headOfDepartment: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Doctor'
  },
  doctors: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Doctor'
  }],
  location: {
    floor: {
      type: Number,
      required: [true, 'Please provide floor number']
    },
    room: {
      type: String,
      required: [true, 'Please provide room number']
    },
    building: {
      type: String,
      required: [true, 'Please provide building name']
    }
  },
  contactInfo: {
    phone: {
      type: String,
      required: [true, 'Please provide department phone number'],
      match: [/^[\+]?[1-9][\d]{0,15}$/, 'Please provide a valid phone number']
    },
    email: {
      type: String,
      required: [true, 'Please provide department email'],
      lowercase: true,
      match: [/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/, 'Please provide a valid email']
    }
  },
  services: [{
    name: String,
    description: String,
    price: Number
  }],
  operatingHours: {
    monday: { start: String, end: String, isOpen: Boolean },
    tuesday: { start: String, end: String, isOpen: Boolean },
    wednesday: { start: String, end: String, isOpen: Boolean },
    thursday: { start: String, end: String, isOpen: Boolean },
    friday: { start: String, end: String, isOpen: Boolean },
    saturday: { start: String, end: String, isOpen: Boolean },
    sunday: { start: String, end: String, isOpen: Boolean }
  },
  isActive: {
    type: Boolean,
    default: true
  },
  capacity: {
    type: Number,
    required: [true, 'Please provide department capacity'],
    min: [1, 'Capacity must be at least 1']
  },
  currentOccupancy: {
    type: Number,
    default: 0,
    min: [0, 'Current occupancy cannot be negative']
  }
}, {
  timestamps: true
});

// Index for better query performance
departmentSchema.index({ name: 1 });
departmentSchema.index({ isActive: 1 });

// Virtual for availability
departmentSchema.virtual('isAvailable').get(function() {
  return this.currentOccupancy < this.capacity;
});

export default mongoose.model('Department', departmentSchema);
